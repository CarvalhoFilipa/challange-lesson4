function formatDate(date) {
  let hours = date.getHours();
  if (hours < 10) {
    hours = `0${hours}`;
  }
  let minutes = date.getMinutes();
  if (minutes < 10) {
    minutes = `0${minutes}`;
  }
  let days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  let day = days[date.getDay()];
  return `${day}, ${hours}:${minutes}`;
}
function changeCity(event) {
  event.preventDefault();
  let city = document.querySelector("#city-input");

  let cityNameChange = document.querySelector("#city-name");
  cityNameChange.innerHTML = `${city.value}`;
}
function convertFahrenheit(event) {
  event.preventDefault();
  let temperature = document.querySelector(".temperature");
  let fahr = 82;
  temperature.innerHTML = `${fahr}`;
}
function convertCelsius(event) {
  event.preventDefault();
  let temperature = document.querySelector(".temperature");
  let cels = 28;
  temperature.innerHTML = `${cels}`;
}

//Date (day, 00:00)
let now = new Date();
let currentDate = document.querySelector(".current-date");
currentDate.innerHTML = formatDate(now);

//Show city name
let form = document.querySelector("#search-form");
form.addEventListener("submit", changeCity);

//diplay Celsius to Fahrenheit
let fahrenheit = document.querySelector("#fahrenheit");
let celsius = document.querySelector("#celsius");
fahrenheit.addEventListener("click", convertFahrenheit);
celsius.addEventListener("click", convertCelsius);
